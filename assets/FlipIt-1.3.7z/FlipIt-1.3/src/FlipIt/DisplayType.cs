﻿namespace ScreenSaver
{
    public enum DisplayType
    {
        None = 0,
        CurrentTime = 1,
        WorldTime = 6
    }
}